<?php include("connection.php");?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="styledonor.css">
        <title>cause</title>
    </head>
    <body>
    <form>
            <input type="button" value="BACK" onclick="history.back()">
           </form>
        <div class="containers">
            <form action="#" method="POST">
            <div class="title">
               cause
            </div>
        <div class="form">
            
        <div class="input_field">
            <label>Select Cause</label>
            
                <select class="select" name="cid">
                <option value="">Select</option>
                    <option value="1">GIRL EDUCATION</option>
                    <option value="2">SUPPORT ORPHANAGES AND OLD AGE HOMES</option>
                    <option value="3">CANCER PREVENTION AND TREATMENT</option>
                    <option value="4">STRAY ANIMAL RESCUE</option>
                </select>
            </div>

            <div class="input_field">
                <label>Amount</label>
                <input style="color:white" type="text" class="input" name="amount">
            </div>

            <div class="input_field">
                <label>Mode of Transaction</label>
                <input style="color:white" type="text" class="input" name="mode">
            </div>

            <div class="input_field">
              
                <input type="submit" value="submit" class="btn" name="register">
            </div>
            </div>
            </div>
            </div>

        </div>
</form>
        </div>
    </body>
    </html>

    <?php
     if(isset($_POST['register']))
     {
        
        $cause = $_POST['cid'];
        $amount = $_POST['amount'];
        $mode = $_POST['mode'];
        
    
            $query = "INSERT into donates(cid,amount,mode)values('$cause','$amount','$mode') ";
            $data = mysqli_query($conn, $query) or die(mysqli_error($conn));
            header('location:causes.html');
     }
     else
        {
            //echo "<script>alert('Fields are empty');</script>";
        }
    ?>
