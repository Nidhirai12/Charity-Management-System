<?php
include("connection.php");
$id = $_GET['id'];

$query = "DELETE FROM DONOR WHERE did='$id' ";
$data = mysqli_query($conn, $query);
header('location:display.php');
if($data)
{
    echo "<script>alert('Record Deleted');</script>";
    
}
else
{
    echo "failed to delete";
}
?>