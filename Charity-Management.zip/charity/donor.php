<?php include("connection.php");?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="styledonor.css">
        <title>donation</title>
    </head>
    <body>
    <form>
            <input type="button" value="BACK" onclick="history.back()">
           </form>
        <div class="containers">
            <form action="#" method="POST">
            <div class="title">
               Donation form
            </div>
        <div class="form">
            <div class="input_field">
                <label>First Name</label>
                <input style="color:white" type="text" class="input" name="fname">
            </div>
            <div class="input_field">
                <label>Last Name</label>
                <input style="color:white" type="text" class="input" name="lname">
            </div>
            <div class="input_field">
                <label>Age</label>
                <input style="color:white" type="text" class="input" name="age">
            </div>
            <div class="input_field">
                <label>Gender</label>
                
                <select style="color:white" class="select" name="gender">
                <option style="color:black"value="">Select</option>
                    <option style="color:black">Male</option>
                    <option style="color:black">female</option>
                </select>
            </div>
            <div class="input_field">
                <label>Phone Number</label>
                <input style="color:white" type="text" class="input" name="phno">
            </div>

            <div class="input_field">
                <label>House.No</label>
                <input style="color:white" type="text" class="input" name="houseno">
            </div>
            <div class="input_field">
                <label>Locality</label>
                <input style="color:white" type="text" class="input" name="locality">
            </div>
            <div class="input_field">
                <label>City</label>
                <input style="color:white" type="text" class="input" name="city">
            </div>
            <div class="input_field">
                <label>State</label>
                <input style="color:white" type="text" class="input" name="state">
            </div>
            <div class="input_field">
                <label>Pincode</label>
                <input style="color:white" type="text" class="input" name="pincode">
            </div>
            

            <div class="input_field">
                               
                <input style="color:black" type="submit" value="NEXT" class="btn" name="register">
                
</div>     
        </div>
</form>
        </div>
    </body>
    </html>

    <?php
     if($_POST['register'])
     {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $phno = $_POST['phno'];
        $houseno = $_POST['houseno'];
        $locality = $_POST['locality'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $pincode = $_POST['pincode'];
        if ($fname != "" && $lname != "" && $age != "" && $gender != "" && $phno != "" && $houseno != "" && $locality != "" && $city != "" && $state != "" && $pincode != "") {
            $query = "INSERT INTO donor values('','$fname','$lname','$age','$gender','$phno','$houseno','$locality','$city','$state','$pincode')  ";
            $data = mysqli_query($conn, $query);
            header('location:donate.php');
            header('location:cause.php');
            if ($data) {
                echo "data inserted into database";
            } else {
                echo "failed";
            }
        }
        else
        {
            //echo "<script>alert('Fields are empty');</script>";
        }
     }
    ?>
