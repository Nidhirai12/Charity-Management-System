<html>
    <head>
        <link rel="stylesheet" type="text/css" href=styledisplay.css>
        <title>Display</title>
        <style>
            <body>

    
            <form>
            <input type="button" value="BACK" onclick="history.back()">
           </form>
         


                {
                    background:black; 
                }
                table{
                    width:90%;
                    border-collapse: collapse;
                    margin-right: auto;
                    margin-left: auto;
                    margin-top: 0;
                    margin-bottom: 0;
                    
                }
                table,th,td{
                    background-image:url(wp9764105.webp) ;
                    background-color:black;
                    opacity:0.75;
                    font-family: century gothic;
                    font-size: 17px;
                    color:white;
                    font-weight: bolder;
                    padding:2px 2px;
                    text-align: center;
                   
                   
                }
                h2{
                    
                    opacity:30px;
                    height:40px;
                    text-align:center;
                    color:white;
                    float:center;
                    display: center;
                    justify-content: center;
                    font-size: 30px;
                    font-weight: bold;
                    padding:50px 15px;
                    padding-bottom: 10px;
                    margin-right: auto;
                    margin-left: auto;
                    margin-top: 0;
                    margin-bottom: 0;
                }
                .update,.delete
                {
                    background-color: greenyellow;
                    color: black;
                    border: 0;
                    outline: none;
                    border-radius: 5px;
                    height: 20px;
                    width: 60px;
                    font-weight: bold;
                    cursor: pointer;
                    font-family: century gothic;
                    font-size: 12px;
                }
                .delete
                {
                    background-color: #ff6666;
                    
                }
                .display .insert 
                {
                    background-color: lightseagreen;
                    width:90px;
                    height:40px;
                    font-size: 20px;
                    background-image:url(wp9764105.webp) ;
                    width:900px;
                    float:center;
                    display: center;
                    justify-content: center;
                    margin-right: auto;
                    margin-left: auto;
                    margin-top: 0;
                    margin-bottom: 0;
                    opacity: 0.75;
                    color:white;
                   
                    
                    
                }
              
            </body>
            </style>
            
         
</head>
</html>



<?php

include("connection.php");
error_reporting(0);

$query = "SELECT * FROM donor";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);



//echo $total;;


if($total != 0)
{ 
    ?>
    <div class="display">
    
    <h2 align="center">RECORDS OF DONORS</h2>
    <br>
    <div class="insert">
    <a href='donor.php?id=$result[did]'><input type='btn' value='INSERT' class='insert'></a>
    </div>
    <br>
    
    <center><table border="1" cellspacing="7" width="100%">
        <tr>
        <th width="5%">DID</th>
        <th width="9%">FIRST NAME</th>
        <th width="8%">LAST NAME</th>
        <th width="4%">AGE</th>
        <th width="6%">GENDER</th>
        <th width="6%">PHONE NUMBER</th>
        <th width="6%">HOUSENO</th>
        <th width="8%">LOCALITY</th>
        <th width="8%">CITY</th>
        <th width="8%">STATE</th>
        <th width="6%">PINCODE</th>
        <th width="19%">OPERATIONS</th>
        </tr>
        </div>
       
    <?php   
    
    while($result = mysqli_fetch_assoc($data))
    
        {
            echo "<tr>
            <td>".$result['did']."</td>
            <td>".$result['fname']."</td>
            <td>".$result['lname']."</td>
            <td>".$result['age']."</td>
            <td>".$result['gender']."</td>
            <td>".$result['phno']."</td>
            <td>".$result['houseno']."</td>
            <td>".$result['locality']."</td>
            <td>".$result['city']."</td>
            <td>".$result['state']."</td>
            <td>".$result['pincode']."</td>
           
            
            <td><a href='update.php?id=$result[did]'><input type='submit' value='update' class='update'></a>
            <a href='delete.php?id=$result[did]'><input type='submit' value='delete' class='delete'></a></td>
           
          </tr>
          "; 
            
                
                
                
        }
}
else
{
    echo "no records found";
}


?>
    </table>
    </center>

 


    <html>
    <head>
        <title>Display</title>
        <style>
            <body>
                {
                    background:black;
                    
                }
                table{
                    
                    background-color: black;
                    margin-right: auto;
                    margin-left: auto;
                    margin-top: 0;
                    margin-bottom: 0;
                }
                
                .update,.delete,.insert
                {
                    background-color:greenyellow;
                    color: black;
                    border: 0;
                    outline: none;
                    border-radius: 5px;
                    height: 20px;
                    width: 60px;
                    font-weight: bold;
                    cursor: pointer;
                    font-size: 12px;
                    text-align: center;
                }
                .delete
                {
                    background-color: #ff6666;
                    
                }
                .display .insert 
                {
                    background-color: lightseagreen;
                    width:90px;
                    height:40px;
                    font-size: 20px;
                 
                    width:900px;
                    float:center;
                    display: center;
                    justify-content: center;
                    margin-right: auto;
                    margin-left: auto;
                    margin-top: 0;
                    margin-bottom: 0;
                    
                   
                    
                    
                }
              
                
            </body>
            </style>
            
         
</head>
</html>



<?php
include("connection.php");
error_reporting(0);

$query = "SELECT * FROM employee";
$data = mysqli_query($conn, $query);

$total = mysqli_num_rows($data);



//echo $total;;


if($total != 0)
{ 
    ?>
    <div class="display">
    <br>
    <h2 align="center">RECORDS OF EMPLOYEES</h2>
    <br>
    <div class="insert">
    <a href='employee.php?id=$result[eid]'><input type='submit' value='INSERT' class='insert'></a>
    </div>
    <br>
    <center><table border="1" cellspacing="7" width="100%">
        <tr>
        <th width="5%">EID</th>
        <th width="8%">ENAME</th>
        <th width="4%">AGE</th>
        <th width="10%">PHONE</th>
        <th width="6%">HOUSENO</th>
        <th width="8%">LOCALITY</th>
        <th width="8%">CITY</th>
        <th width="8%">STATE</th>
        <th width="6%">PINCODE</th>
        <th width="19%">OPERATIONS</th>
        </tr>
        </div>
       
    <?php   
    
    while($result = mysqli_fetch_assoc($data))
    
        {
            echo "<tr>
            <td>".$result['eid']."</td>
            <td>".$result['ename']."</td>
            <td>".$result['age']."</td>
            <td>".$result['phone']."</td>
            <td>".$result['houseno']."</td>
            <td>".$result['locality']."</td>
            <td>".$result['city']."</td>
            <td>".$result['state']."</td>
            <td>".$result['pincode']."</td>
            
            <td><a href='empupdate.php?id=$result[eid]'><input type='submit' value='update' class='update'></a>
            <a href='empdelete.php?id=$result[eid]'><input type='submit' value='delete' class='delete'></a></td>
           
          </tr>
          ";        
                
        }
}
else
{
    echo "no records found";
}


?>
    </table>
    </center>

 


   