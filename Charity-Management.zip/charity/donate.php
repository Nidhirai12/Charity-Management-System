<?php
// creating a connection by passing server name,
// username, password and database name
// servername=localhost
// username=root
// password=empty
// database name= geeks_database
$connection_link = new mysqli("localhost", "root", "","charity");

if ($connection_link == false) {
	echo "ERROR";
}

//sql query to perform copying data from one table to another
$sql_query = "INSERT INTO donates(did) select did from donor";
	if ($connection_link->query($sql_query) === true)
{
	echo "Data Copied Successfully.";
}
else
{
	echo "ERROR: Could not able to proceed $sql_query. "
		.$connection_link->error;
}

// Close the connection
$connection_link->close();
?>
