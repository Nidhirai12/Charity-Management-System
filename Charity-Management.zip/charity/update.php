
<?php include("connection.php");
$id = $_GET['id'];
$query = "SELECT * FROM donor where did = '$id'";
$data = mysqli_query($conn, $query);
$result = mysqli_fetch_assoc($data);
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <link rel="stylesheet" type="text/css" href="styleupdate.css">
        <title>update</title>
    </head>
    <body>
        <div class="container">
            <form action="#" method="POST">
            <div class="title">
               Updation form
            </div>
        <div class="form">
            <div class="input_field">
                <label>First Name</label>
                <input style="color:white" type="text" value="<?php echo $result['fname']; ?>" class="input" name="fname" required>
            </div>
            <div class="input_field">
                <label>Last Name</label>
                <input style="color:white" type="text" value="<?php echo $result['lname']; ?>" class="input" name="lname" required>
            </div>
            <div class="input_field">
                <label>Age</label>
                <input style="color:white" type="text" value="<?php echo $result['age'];  ?>" class="input" name="age" required>
            </div>
            
            <div class="input_field">
                <label>Gender</label>
                <select style="color:white" class="select" name="gender" required>
                    <option style="color:black" value="">Select</option>

                    <option  style="color:black" value="male"
                       <?php
                       if($result['gender'] == 'male') 
                       {
                           echo "selected";
                       }
                       ?>
                    >male</option>
                    <option style="color:black" value="female"
                    <?php
                    if($result['gender'] == 'female') 
                    {
                        echo "selected";
                    }
                    ?>
                    >female</option>
                </select>
            </div>
            <div class="input_field">
                <label>Phone Number</label>
                <input style="color:white" type="text" value="<?php echo $result['phno']; ?>" class="input" name="phno" required>
            </div>
            <div class="input_field">
                <label>House no</label>
                <input style="color:white" type="text" value="<?php echo $result['houseno']; ?>" class="input" name="houseno" required>
            </div>
            <div class="input_field">
                <label>Locality</label>
                <input style="color:white" type="text" value="<?php echo $result['locality']; ?>" class="input" name="locality" required>
            </div>
            <div class="input_field">
                <label>City</label>
                <input style="color:white" type="text" value="<?php echo $result['city']; ?>"class="input" name="city" required>
            </div>
            <div class="input_field">
                <label>State</label>
                <input style="color:white" type="text" value="<?php echo $result['state']; ?>" class="input" name="state" required>
            </div>
            <div class="input_field">
                <label>Pincode</label>
                <input style="color:white" type="text" value="<?php echo $result['pincode']; ?>" class="input" name="pincode" required>
            </div>
            <div class="input_field">
                
                <input style="color:black" type="submit" value="UPDATE" class="btn" name="update" >
            </div>
            </div>
            </div>
            </div>

        </div>
</form>
        </div>
    </body>
    </html>

    <?php
     if($_POST['update'])
     {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $phno = $_POST['phno'];
        $houseno = $_POST['houseno'];
        $locality = $_POST['locality'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $pincode = $_POST['pincode'];
            $query = "UPDATE donor set fname='$fname',lname='$lname',age='$age',gender='$gender',phno='$phno',houseno='$houseno',locality='$locality',city='$city',state='$state',pincode='$pincode' WHERE did='$id' ";
            $data = mysqli_query($conn, $query);
            header('location:display.php');
            if ($data) 
            {
                echo "Record updated";
            } else 
            {
                echo "failed";
            }
        } 
    ?>
